# 📊 Sales Data Analysis — Python

## Overview
Exploratory Data Analysis (EDA) on a retail sales dataset using Python.
Covers KPI reporting, trend analysis, regional breakdown, and product performance.

## Tech Stack
- **Python** — Pandas, NumPy, Matplotlib, Seaborn
- **Jupyter Notebook**

## Project Structure
```
sales-analysis-python/
├── data/
│   └── sales_data.csv
├── src/
│   └── analysis.py
├── output/
│   └── charts/
├── requirements.txt
└── README.md
```

## Key Insights
- 📈 Monthly and Quarterly sales trends
- 🗺️ Region-wise revenue breakdown (North, South, East, West)
- 🛒 Top performing products
- 📦 Category-wise split (Electronics vs Furniture)
- 🔥 Heatmap: Region × Category performance

## How to Run

```bash
# 1. Clone the repo
git clone https://github.com/your-username/sales-analysis-python.git
cd sales-analysis-python

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the analysis
python src/analysis.py
```

## Output Charts
| Chart | Description |
|-------|-------------|
| 01_monthly_sales_trend | Month-wise revenue line chart |
| 02_sales_by_region | Region-wise bar chart |
| 03_sales_by_category | Category pie chart |
| 04_top_products | Top 5 products horizontal bar |
| 05_quarterly_revenue | Q1–Q4 revenue comparison |
| 06_heatmap_region_category | Region × Category heatmap |

## Author
**Tulsi Harel**
📧 tulsiharel5@gmail.com
🔗 [LinkedIn](https://linkedin.com/in/tulsi-harel)
