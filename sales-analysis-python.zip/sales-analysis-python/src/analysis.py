"""
Sales Data Analysis
Author: Tulsi Harel
Description: Exploratory Data Analysis on Sales Dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import os

# ── Setup ──────────────────────────────────────────────
sns.set_theme(style="whitegrid", palette="muted")
os.makedirs("output/charts", exist_ok=True)

# ── 1. Load Data ───────────────────────────────────────
df = pd.read_csv("data/sales_data.csv", parse_dates=["Date"])
print("=" * 50)
print("SALES DATA — OVERVIEW")
print("=" * 50)
print(df.head())
print(f"\nShape: {df.shape[0]} rows × {df.shape[1]} columns")
print(f"\nData Types:\n{df.dtypes}")
print(f"\nMissing Values:\n{df.isnull().sum()}")

# ── 2. Feature Engineering ─────────────────────────────
df["Month"]      = df["Date"].dt.month_name()
df["Month_Num"]  = df["Date"].dt.month
df["Quarter"]    = df["Date"].dt.quarter.map({1:"Q1", 2:"Q2", 3:"Q3", 4:"Q4"})

# ── 3. KPI Summary ─────────────────────────────────────
print("\n" + "=" * 50)
print("KEY PERFORMANCE INDICATORS")
print("=" * 50)
total_sales   = df["Total_Sales"].sum()
total_orders  = df["Order_ID"].nunique()
avg_order_val = df["Total_Sales"].mean()
total_qty     = df["Quantity"].sum()

print(f"  Total Revenue    : ₹{total_sales:,.0f}")
print(f"  Total Orders     : {total_orders}")
print(f"  Avg Order Value  : ₹{avg_order_val:,.0f}")
print(f"  Total Units Sold : {total_qty}")

# ── 4. Monthly Sales Trend ─────────────────────────────
monthly = (df.groupby(["Month_Num", "Month"])["Total_Sales"]
             .sum()
             .reset_index()
             .sort_values("Month_Num"))

fig, ax = plt.subplots(figsize=(12, 5))
ax.plot(monthly["Month"], monthly["Total_Sales"], marker="o",
        linewidth=2.5, color="#1B3A6B", markersize=8)
ax.fill_between(monthly["Month"], monthly["Total_Sales"],
                alpha=0.15, color="#1B3A6B")
ax.set_title("Monthly Sales Trend (2024)", fontsize=15, fontweight="bold", pad=15)
ax.set_xlabel("Month", fontsize=11)
ax.set_ylabel("Total Sales (₹)", fontsize=11)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e5:.1f}L"))
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig("output/charts/01_monthly_sales_trend.png", dpi=150)
plt.close()
print("\n✅ Chart saved: 01_monthly_sales_trend.png")

# ── 5. Sales by Region ─────────────────────────────────
region = df.groupby("Region")["Total_Sales"].sum().sort_values(ascending=False)

fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(region.index, region.values, color=["#1B3A6B","#2E6DA4","#4A90C4","#7AB8D9"])
ax.set_title("Total Sales by Region", fontsize=15, fontweight="bold", pad=15)
ax.set_xlabel("Region", fontsize=11)
ax.set_ylabel("Total Sales (₹)", fontsize=11)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e5:.1f}L"))
for bar in bars:
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + 5000,
            f"₹{bar.get_height()/1e5:.1f}L",
            ha="center", fontsize=10, fontweight="bold")
plt.tight_layout()
plt.savefig("output/charts/02_sales_by_region.png", dpi=150)
plt.close()
print("✅ Chart saved: 02_sales_by_region.png")

# ── 6. Sales by Category ───────────────────────────────
category = df.groupby("Category")["Total_Sales"].sum()

fig, ax = plt.subplots(figsize=(7, 7))
colors = ["#1B3A6B", "#4A90C4"]
wedges, texts, autotexts = ax.pie(
    category.values, labels=category.index,
    autopct="%1.1f%%", colors=colors,
    startangle=140, pctdistance=0.75,
    wedgeprops={"edgecolor": "white", "linewidth": 2}
)
for t in autotexts:
    t.set_fontsize(13)
    t.set_fontweight("bold")
    t.set_color("white")
ax.set_title("Sales by Category", fontsize=15, fontweight="bold", pad=15)
plt.tight_layout()
plt.savefig("output/charts/03_sales_by_category.png", dpi=150)
plt.close()
print("✅ Chart saved: 03_sales_by_category.png")

# ── 7. Top 5 Products ──────────────────────────────────
top_products = (df.groupby("Product")["Total_Sales"]
                  .sum()
                  .sort_values(ascending=True)
                  .tail(5))

fig, ax = plt.subplots(figsize=(9, 5))
bars = ax.barh(top_products.index, top_products.values, color="#1B3A6B")
ax.set_title("Top 5 Products by Sales", fontsize=15, fontweight="bold", pad=15)
ax.set_xlabel("Total Sales (₹)", fontsize=11)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e5:.1f}L"))
for bar in bars:
    ax.text(bar.get_width() + 3000,
            bar.get_y() + bar.get_height()/2,
            f"₹{bar.get_width()/1e5:.1f}L",
            va="center", fontsize=10, fontweight="bold")
plt.tight_layout()
plt.savefig("output/charts/04_top_products.png", dpi=150)
plt.close()
print("✅ Chart saved: 04_top_products.png")

# ── 8. Quarterly Revenue ───────────────────────────────
quarterly = df.groupby("Quarter")["Total_Sales"].sum()

fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(quarterly.index, quarterly.values,
              color=["#1B3A6B","#2E6DA4","#4A90C4","#7AB8D9"], width=0.5)
ax.set_title("Quarterly Revenue (2024)", fontsize=15, fontweight="bold", pad=15)
ax.set_xlabel("Quarter", fontsize=11)
ax.set_ylabel("Total Sales (₹)", fontsize=11)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"₹{x/1e5:.1f}L"))
for bar in bars:
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + 3000,
            f"₹{bar.get_height()/1e5:.1f}L",
            ha="center", fontsize=11, fontweight="bold")
plt.tight_layout()
plt.savefig("output/charts/05_quarterly_revenue.png", dpi=150)
plt.close()
print("✅ Chart saved: 05_quarterly_revenue.png")

# ── 9. Region × Category Heatmap ──────────────────────
pivot = df.pivot_table(values="Total_Sales", index="Region",
                       columns="Category", aggfunc="sum")

fig, ax = plt.subplots(figsize=(8, 5))
sns.heatmap(pivot, annot=True, fmt=".0f", cmap="Blues",
            linewidths=0.5, ax=ax,
            annot_kws={"size": 10})
ax.set_title("Sales Heatmap: Region × Category (₹)", fontsize=14, fontweight="bold", pad=15)
plt.tight_layout()
plt.savefig("output/charts/06_heatmap_region_category.png", dpi=150)
plt.close()
print("✅ Chart saved: 06_heatmap_region_category.png")

# ── 10. Summary Table ──────────────────────────────────
print("\n" + "=" * 50)
print("MONTHLY SALES SUMMARY")
print("=" * 50)
summary = (df.groupby(["Month_Num", "Month"])
             .agg(Total_Sales=("Total_Sales","sum"),
                  Total_Orders=("Order_ID","count"),
                  Avg_Order_Value=("Total_Sales","mean"))
             .sort_values("Month_Num")
             .reset_index(drop=False)
             .drop("Month_Num", axis=1))
summary["Total_Sales"]     = summary["Total_Sales"].map("₹{:,.0f}".format)
summary["Avg_Order_Value"] = summary["Avg_Order_Value"].map("₹{:,.0f}".format)
print(summary.to_string(index=False))

print("\n✅ Analysis Complete! Check output/charts/ for all visualizations.")
